from tests.support import PROJECT_ROOT
import ast
import re
import unittest
from pathlib import Path


ROOT = PROJECT_ROOT
BOT = ROOT / "app" / "bot" / "main.py"
HUBS = ROOT / "app" / "bot" / "hubs.py"


class CommandCleanupTests(unittest.TestCase):
    def test_player_surface_keeps_compact_roots_plus_admin(self):
        tree = ast.parse(BOT.read_text(encoding="utf-8"))
        hub_names = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if not isinstance(node.func, ast.Name) or node.func.id != "HubDefinition":
                continue
            for kw in node.keywords:
                if kw.arg == "name" and isinstance(kw.value, ast.Constant):
                    hub_names.append(str(kw.value.value))
        self.assertEqual(
            set(hub_names),
            {
                "character", "quest", "cultivation", "items", "npc", "world",
                "travel", "combat", "economy", "craft", "beast", "sect",
                "family", "abode", "innerworld", "realm", "admin",
            },
        )
        self.assertEqual(len(hub_names), 17)
        # /begin, /action and /check remain direct convenience roots.
        source = BOT.read_text(encoding="utf-8")
        for name in ("begin", "action", "check"):
            self.assertRegex(source, rf'@registered_root_command\([^\n]*name="{name}"|@registered_root_command\(name="{name}"')

    def test_internal_action_groups_are_not_registered_as_slash_roots(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertNotIn("tree.get_command(", source)
        self.assertNotIn("tree.remove_command(", source)
        self.assertIn("def register_command_surface", source)
        self.assertIn("client.tree.add_command(ACTIONS.root(name), guild=GUILD)", source)
        self.assertNotIn("bot.tree.add_command(admin_group, guild=GUILD)", source)
        self.assertIn('name="admin",', source)
        self.assertIn("async def admin_panel", source)
        self.assertIn("_MIGRATED_ROOTS", source)
        migrated_node = next(node for node in ast.parse(source).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "_MIGRATED_ROOTS" for target in node.targets))
        self.assertEqual(len(ast.literal_eval(migrated_node.value)), 74)
        self.assertNotIn("tree.remove_command", source)
        self.assertIn('"alchemy": alchemy_group', source)
        self.assertIn('_hub_page("alchemy", "Alchemy"', source)

    def test_private_expedition_copy_uses_registered_world_hub(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn('"explore"', source[source.index("_MIGRATED_ROOTS"):source.index("_ROOT_ACTIONS")])
        self.assertIn('_hub_page("explore", "Explore"', source)
        self.assertIn("**/world → Explore**", source)
        self.assertIn("**/action**", source)
        self.assertNotIn("**/explore**", source)
        self.assertNotIn("**/act**", source)

    def test_admin_is_a_single_dropdown_panel_with_all_registered_actions(self):
        source = BOT.read_text(encoding="utf-8")
        groups = [
            "admin_server_group", "admin_world_group", "admin_player_group",
            "admin_sect_group", "admin_family_group", "admin_npc_group", "admin_sim_group",
        ]
        total = 0
        for group in groups:
            commands = re.findall(rf"@registered_group_command\({group},\s*name=\"([^\"]+)\"", source)
            self.assertLessEqual(len(commands), 25, group)
            total += len(commands)
        self.assertEqual(total, 40)
        self.assertIn("_ADMIN_HUB_DEFINITION = HubDefinition(", source)
        self.assertIn('title="🛡️ Xianxia — Administrator Control Panel"', source)
        self.assertIn("command=admin_server_group", source)
        self.assertIn("command=admin_sim_group", source)
        self.assertIn("@app_commands.default_permissions(administrator=True)", source)
        self.assertNotIn("bot.tree.add_command(admin_group, guild=GUILD)", source)

    def test_stage7_bot_never_provisions_server_channels(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertNotIn("guild.create_text_channel", source)
        self.assertNotIn("guild.create_category", source)
        self.assertIn("Discord channel creation is dashboard-owned", source)
        self.assertIn("the bot will not provision channels", source)

    def test_deleted_configured_channels_are_treated_as_stale(self):
        source = BOT.read_text(encoding="utf-8")
        self.assertIn('except discord.NotFound:', source)
        self.assertIn('treating binding as stale', source)


    def test_hub_public_replies_use_interaction_webhook_and_chunk_long_text(self):
        source = HUBS.read_text(encoding="utf-8")
        self.assertIn("def _hub_content_chunks", source)
        self.assertIn("source.edit_original_response", source)
        self.assertIn("interaction.edit_original_response", source)
        self.assertIn("hub_error_reporter", source)
        self.assertIn("await self.owner.source.followup.send(chunk, ephemeral=False)", source)

    def test_world_output_uses_shared_long_reply_helper(self):
        source = BOT.read_text(encoding="utf-8")
        start = source.index('@registered_root_command(name="world"')
        end = source.index('@registered_root_command(name="worldevents"', start)
        world_block = source[start:end]
        self.assertIn('await reply_long(interaction, "".join(lines), ephemeral=False)', world_block)

    def test_only_begin_flow_can_send_ephemeral_responses(self):
        allowed_private_classes = {
            "CharacterModal",
            "BirthFamilyPreviousButton",
            "BirthFamilyChooseButton",
            "BirthFamilyNextButton",
            "CultivationStyleSelect",
            "BirthSexSelect",
            "BirthFamilyBackButton",
            "BirthFamilyConfirmButton",
            "BirthFamilyView",
        }
        violations = []

        class VisibilityVisitor(ast.NodeVisitor):
            def __init__(self):
                self.scopes = []

            def visit_ClassDef(self, node):
                self.scopes.append(node.name)
                self.generic_visit(node)
                self.scopes.pop()

            def visit_FunctionDef(self, node):
                self.scopes.append(node.name)
                self.generic_visit(node)
                self.scopes.pop()

            visit_AsyncFunctionDef = visit_FunctionDef

            def visit_Call(self, node):
                for keyword in node.keywords:
                    if keyword.arg != "ephemeral":
                        continue
                    is_public = isinstance(keyword.value, ast.Constant) and keyword.value.value is False
                    is_begin_flow = "begin" in self.scopes or any(
                        scope in allowed_private_classes for scope in self.scopes
                    )
                    forwards_begin_choice = "_report_game_ui_error" in self.scopes
                    if not (is_public or is_begin_flow or forwards_begin_choice):
                        violations.append((node.lineno, ast.unparse(keyword.value)))
                self.generic_visit(node)

        for path in (BOT, HUBS):
            VisibilityVisitor().visit(ast.parse(path.read_text(encoding="utf-8")))

        self.assertEqual(violations, [])

        source = BOT.read_text(encoding="utf-8")
        begin_start = source.index('@registered_root_command(name="begin"')
        begin_end = source.index("GENDER_CHOICES", begin_start)
        self.assertIn("ephemeral=True", source[begin_start:begin_end])

    def test_stage7_dashboard_owned_channels_do_not_apply_setup_overwrites(self):
        source = BOT.read_text(encoding="utf-8")
        setup_start = source.index("async def ensure_base_xianxia_channels")
        setup_end = source.index("@registered_group_command(admin_server_group, name=\"basechannels\"", setup_start)
        setup_block = source[setup_start:setup_end]
        self.assertNotIn("set_permissions(", setup_block)
        self.assertNotIn("PermissionOverwrite(", setup_block)
        self.assertIn("Discord channel creation is dashboard-owned", source)
        self.assertIn("the bot will not provision channels", source)

    def test_reusable_hub_framework_enforces_owner_and_uses_registered_handlers(self):
        source = HUBS.read_text(encoding="utf-8")
        for required in (
            "class CommandHubView", "interaction_check", "on_timeout",
            "class HubQuickActionButton", "class HubPageButton",
            "class HubActionModal", "class HubPageSelect", "class HubActionSelect",
            "class HubMemberSelect", "class HubContinueInputView", "HubInteractionProxy", "action.handler",
            "response.edit_message", "message.edit",
        ):
            self.assertIn(required, source)
        self.assertIn("interaction.user.id != self.owner_id", source)
        self.assertIn("command_override=action.command", source)
        self.assertIn("if self.definition.name == \"admin\"", source)

    def test_refactored_packages_have_no_legacy_module_shims(self):
        self.assertTrue((ROOT / "app" / "bot" / "main.py").is_file())
        self.assertTrue((ROOT / "app" / "database" / "core.py").is_file())
        self.assertTrue((ROOT / "app" / "simulation" / "world.py").is_file())
        self.assertFalse((ROOT / "app" / "bot.py").exists())
        self.assertFalse((ROOT / "app" / "database.py").exists())
        self.assertFalse((ROOT / "app" / "worldsim.py").exists())

    def test_hubs_resolve_explicit_handlers_without_callback_introspection(self):
        hub_source = HUBS.read_text(encoding="utf-8")
        registry_source = (ROOT / "app" / "bot" / "registry.py").read_text(encoding="utf-8")
        self.assertIn("handler=ACTIONS.handler_for(item)", hub_source)
        self.assertIn("await action.handler(proxy", hub_source)
        self.assertNotIn("action.command.callback", hub_source)
        self.assertIn("class ActionRegistry", registry_source)



if __name__ == "__main__":
    unittest.main()


def test_admin_invocations_are_mirrored_to_private_discord_log():
    source = Path("app/bot/main.py").read_text()
    assert "async def log_admin_command_invocation" in source
    assert 'post_server_log(interaction.guild, "Admin command", detail)' in source
    assert "await log_admin_command_invocation(interaction)" in source
    assert "_admin_command_option_summary" in source
